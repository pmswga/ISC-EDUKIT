var menudata={children:[
{text:"Титульная страница",url:"index.html"},
{text:"Описания",url:"pages.html"},
{text:"Пространства имен",url:"namespaces.html",children:[
{text:"Пространства имен",url:"namespaces.html"}]},
{text:"Структуры данных",url:"annotated.html",children:[
{text:"Структуры данных",url:"annotated.html"},
{text:"Алфавитный указатель структур данных",url:"classes.html"},
{text:"Иерархия классов",url:"hierarchy.html"},
{text:"Поля структур",url:"functions.html",children:[
{text:"Указатель",url:"functions.html",children:[
{text:"$",url:"functions.html#index_0x24"},
{text:"_",url:"functions__.html#index__"},
{text:"a",url:"functions_a.html#index_a"},
{text:"c",url:"functions_c.html#index_c"},
{text:"d",url:"functions_d.html#index_d"},
{text:"g",url:"functions_g.html#index_g"},
{text:"i",url:"functions_i.html#index_i"},
{text:"m",url:"functions_m.html#index_m"},
{text:"p",url:"functions_p.html#index_p"},
{text:"q",url:"functions_q.html#index_q"},
{text:"r",url:"functions_r.html#index_r"},
{text:"s",url:"functions_s.html#index_s"},
{text:"t",url:"functions_t.html#index_t"},
{text:"u",url:"functions_u.html#index_u"}]},
{text:"Функции",url:"functions_func.html",children:[
{text:"_",url:"functions_func.html#index__"},
{text:"a",url:"functions_func_a.html#index_a"},
{text:"c",url:"functions_func_c.html#index_c"},
{text:"d",url:"functions_func_d.html#index_d"},
{text:"g",url:"functions_func_g.html#index_g"},
{text:"i",url:"functions_func_i.html#index_i"},
{text:"m",url:"functions_func_m.html#index_m"},
{text:"p",url:"functions_func_p.html#index_p"},
{text:"q",url:"functions_func_q.html#index_q"},
{text:"r",url:"functions_func_r.html#index_r"},
{text:"s",url:"functions_func_s.html#index_s"},
{text:"t",url:"functions_func_t.html#index_t"},
{text:"u",url:"functions_func_u.html#index_u"}]},
{text:"Переменные",url:"functions_vars.html",children:[
{text:"$",url:"functions_vars.html#index_0x24"}]}]}]},
{text:"Файлы",url:"files.html",children:[
{text:"Файлы",url:"files.html"},
{text:"Список членов всех файлов",url:"globals.html",children:[
{text:"Указатель",url:"globals.html"},
{text:"Переменные",url:"globals_vars.html"}]}]}]}
